﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class RoadHazard
    {
        [Key]
        public int RoadHazardId { get; set;}

        public int RoadId { get; set;}
        public int HazardId { get; set;}

        [ForeignKey(nameof(RoadId))]
        public Road Road { get; set;}

        [ForeignKey(nameof(HazardId))]
        public Hazard Hazard { get; set;}


        public RoadHazard (int roadId, int hazardId)
        {
            RoadId = roadId;
            HazardId = hazardId;
        }

        public RoadHazard() { }
    }
}