﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class Road
    {
        [Key]
        public int RoadId { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }

       public List<RoadCrash> RoadCrashes { get; set; } = new List<RoadCrash>();

        public List<RoadHazard> RoadHazards { get; set; } = new List<RoadHazard>();

        public Road (string name, string city, string state, string zip)
        {
            Name = name;
            City = city;
            State = state;
            Zip = zip;
        }

        public Road() { }

    }
}