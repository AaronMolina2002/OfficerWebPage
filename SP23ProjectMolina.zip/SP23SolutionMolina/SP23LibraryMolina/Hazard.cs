﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class Hazard
    {
        [Key]
        public int HazardId { get; set; }
        public string HazardType { get; set; }

        public List<RoadHazard> RoadHazards { get; set; } = new List<RoadHazard>();

        public Hazard(string hazardType)
        {
            this.HazardType = hazardType;
        }

        public Hazard() { }

    }
}