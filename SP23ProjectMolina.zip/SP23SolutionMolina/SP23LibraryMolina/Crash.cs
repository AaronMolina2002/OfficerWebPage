﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class Crash
    {
        [Key]
        public int CrashID { get; set; }
        public DateTime CrashDateTime { get; set; }

        public DateTime ReportingDateTime { get; set; }

        public Severity SeverityLevel {get; set;}

        public List<OfficerCrash> RespondingOfficers { get; set; } = new List<OfficerCrash>();

        public List<RoadCrash> RoadCrashes { get; set; } = new List<RoadCrash>();

        //Constructors
        public Crash(DateTime crashDateTime, Severity severityLevel = Severity.NonFatalCrash) 
        { 
            CrashDateTime = crashDateTime;
            ReportingDateTime = DateTime.Now;
            SeverityLevel = severityLevel;
        }



        //EF
        public Crash() { }

        public enum Severity
        {
            NonFatalCrash, Severe, ExtremlySevere
        }

        public static implicit operator int(Crash v)
        {
            throw new NotImplementedException();
        }
    }
}