﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class InspectionZone
    {
        [Key]
        public int InspectionZoneId { get; set; }

        public string County { get; set; }

        public string State { get; set; }

        public string StartZip { get; set; }

        public string EndZip { get; set; }

        public string? EngineerId { get; set; }

        [ForeignKey(nameof(EngineerId))]
        public Engineer Engineer { get; set; }

        public InspectionZone(string county, string state, string startZip, string endZip, string engineerId = null)
        {
            County = county;
            State = state;
            StartZip = startZip;
            EndZip = endZip;
            EngineerId = engineerId;
        }

        public InspectionZone () { }

    }
}