﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class RoadCrash
    {
        [Key]
        public int RoadCrashId { get; set; }

        public int CrashId { get; set; }
        public int RoadId { get; set; }

        [ForeignKey(nameof(CrashId))]
        public Crash Crash { get; set; }

        [ForeignKey(nameof(RoadId))]
        public Road Road { get; set; }

        public RoadCrash(int crashId, int roadId)
        {
            this.CrashId = crashId;
            this.RoadId = roadId;
        }

        public RoadCrash() { }
    }
}