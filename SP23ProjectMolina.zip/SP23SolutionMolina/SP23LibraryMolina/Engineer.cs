﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class Engineer : AppUser
    {
        public List<InspectionZone> InspectionZones { get; set; } = new List<InspectionZone>();

        public Engineer(string firstname, string lastname, string phoneNumber, string email, string password) : base(firstname, lastname, phoneNumber, email, password)
        {

        }

        public Engineer() { }
    }
}