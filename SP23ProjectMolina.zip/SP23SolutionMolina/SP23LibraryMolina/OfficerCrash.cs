﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class OfficerCrash
    {
        //PK - MVC?
        [Key]
        public int OfficerCrashId { get; set; }

        //bit to determine role of Officer (Recording or Assisting)
        //bool

        //Relational database connections



        //FK (Relational database connections) - No SQL (MongoDb)
        public int CrashId { get; set; }
        public string OfficerId { get; set; }

        public string OfficerRole { get; set; }
        //public string SeverityOfCrash { get; set; }

        //Object Oriented connections

        [ForeignKey("OfficerId")]
        public Officer Officer { get; set; }
        
        [ForeignKey("CrashId")]//Telling Entity Framework not to create another FK
        public Crash Crash { get; set; }


        //Constructors
        public OfficerCrash(int crashId, string officerId, string officerRole)
        {
            CrashId = crashId;
            OfficerId = officerId;
            OfficerRole = officerRole;
            
        }

        public OfficerCrash() { }

        //public OfficerCrash(int crashId, string? officerId, string officerRole)
        //{
        //    CrashId = crashId;
        //    OfficerId = officerId;
        //    OfficerRole = officerRole;
        //}

        public enum OfficerRoleOptions
        {
            Recording, Assisting
        }
    }
}