﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SP23LibraryMolina
{
    public class Officer : AppUser
    {
        //public int OfficerID { get; set; }

        //public string OfficerRole { get; set; } 

        public List<OfficerCrash> OfficerCrashList { get; set; }
            = new List<OfficerCrash>();



        public Officer(string firstname, string lastname, string phoneNumber, string email, string password) : base(firstname, lastname, phoneNumber, email, password)
        {
            
        }

        public Officer() { }
    }
}