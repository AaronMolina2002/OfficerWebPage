﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Elfie.Serialization;
using Moq;
using NuGet.ContentModel;
using SP23LibraryMolina;
using SP23MvcAppMolina.Controllers;
using SP23MvcAppMolina.Models;
using SP23MvcAppMolina.ViewModels;
using System.ComponentModel.DataAnnotations;

namespace SP23TestMolina
{
    public class RoadTest
    {
        private Mock<IRoadRepo> mockRoadRepo;
        private RoadController controller;

        public RoadTest() 
        {
            this.mockRoadRepo = new Mock<IRoadRepo>();
            this.controller = new RoadController(this.mockRoadRepo.Object);
        }



        [Fact]//This method that follows it is an unit test
        public void ShouldFindAllRoadsWithMostCrashes()
        {
            //AAA
            //Arrange
            List<Road> allRoads = CreateMockRoads();
            this.mockRoadRepo.Setup(m => m.ListAllRoads()).Returns(allRoads);
            FindRoadsViewModel viewModel = new FindRoadsViewModel();
            int expected = allRoads.Count;

            //Act
            ViewResult? result = this.controller.FindRoadsWithMostCrashesResult(viewModel) as ViewResult;// this.controller.FindRoadsWithMostCrashes is an instance method because it does act on an object 
            FindRoadsViewModel? resultViewModel = result?.Model as FindRoadsViewModel;// as followed by class name is casting

            //Assert
            Assert.Equal(expected, resultViewModel?.SearchRoadsResult.Count);// Assert is a class. Assert.Equal is a static method because it does not act on an object. 
        }

        [Fact]//This method that follows it is an unit test
        public void ShouldFindRoadsWithMostCrashesSearchingByRoadID()
        {
            //AAA
            //Arrange
            List<Road> allRoads = CreateMockRoads();
            this.mockRoadRepo.Setup(m => m.ListAllRoads()).Returns(allRoads);
            FindRoadsViewModel viewModel = new FindRoadsViewModel();
            viewModel.RoadId = 1;
            int expected = 1;

            //Act
            ViewResult? result = this.controller.FindRoadsWithMostCrashesResult(viewModel) as ViewResult;
            FindRoadsViewModel? resultViewModel = result?.Model as FindRoadsViewModel;

            //Assert
            Assert.Equal(expected, resultViewModel?.SearchRoadsResult.Count);
            Assert.Equal(viewModel.RoadId, resultViewModel?.SearchRoadsResult?.FirstOrDefault()?.RoadId);
            //Assert.Equal(1, resultViewModel?.SearchRoadsResult.Count);
        }

        [Fact]//This method that follows it is an unit test
        public void ShouldFindRoadsWithMostCrashesBySearchingSeverityLevel()
        {
            //AAA
            //Arrange
            List<Road> allRoads = CreateMockRoads();
            this.mockRoadRepo.Setup(m => m.ListAllRoads()).Returns(allRoads);
            FindRoadsViewModel viewModel = new FindRoadsViewModel();//viewModel represents our search citeria or user inputs.
            viewModel.SeverityLevel = Crash.Severity.NonFatalCrash;//Should return at least one nonfatal crash
            int expected = 1;

            //Act
            ViewResult? result = this.controller.FindRoadsWithMostCrashesResult(viewModel) as ViewResult;// this.controller.FindRoadsWithMostCrashes is an instance method because it does act on an object 
            FindRoadsViewModel? resultViewModel = result?.Model as FindRoadsViewModel;// as followed by class name is casting

            //Assert
            Assert.Equal(expected, resultViewModel?.SearchRoadsResult.Count);// Assert is a class. Assert.Equal is a static method because it does not act on an object. 
            Assert.Equal(expected, resultViewModel?.SearchRoadsResult.Where(r => r.Name == "Beechurst").Count());
        }

        [Fact]//This method that follows it is an unit test
        public void ShouldFindRoadsWithMostCrashesByDate()
        {
            //AAA
            //Arrange
            List<Road> allRoads = CreateMockRoads();
            this.mockRoadRepo.Setup(m => m.ListAllRoads()).Returns(allRoads);
            FindRoadsViewModel viewModel = new FindRoadsViewModel();
            viewModel.StartDate = new DateTime(2023, 07, 01);
            viewModel.EndDate = new DateTime(2023, 08, 1);
            int expected = 1;

            //Act
            ViewResult? result = this.controller.FindRoadsWithMostCrashesResult(viewModel) as ViewResult;// this.controller.FindRoadsWithMostCrashes is an instance method because it does act on an object 
            FindRoadsViewModel? resultViewModel = result?.Model as FindRoadsViewModel;// as followed by class name is casting

            //Assert
            Assert.Equal(expected, resultViewModel?.SearchRoadsResult.Count);// Assert is a class. Assert.Equal is a static method because it does not act on an object. 
            Assert.Equal(expected, resultViewModel?.SearchRoadsResult.Where(r => r.Name == "Beechurst").Count());
        }




        [Fact]
        public void ShouldAddRoad()
        {
            //Arrange
            Road road = null;
            RoadViewModel viewModel = new RoadViewModel();
            viewModel.Name = "Beechurst Ave";
            viewModel.City = "Morgantown";
            viewModel.State = "WV";
            viewModel.Zip = "26505";
            this.mockRoadRepo.Setup(m => m.AddRoad(It.IsAny<Road>())).Returns(1).Callback<Road>(m => road = m);
            this.mockRoadRepo.Setup(m => m.ListAllRoads()).Returns(CreateMockRoads());

            //Act
            this.controller.AddRoad(viewModel);


            //Assert
            this.mockRoadRepo.Verify(m => m.AddRoad(It.IsAny<Road>()),Times.Once);
            Assert.Equal(viewModel.Name, road.Name);
            Assert.Equal(viewModel.City, road.City);
            Assert.Equal(viewModel.State, road.State);
            Assert.Equal(viewModel.Zip, road.Zip);
        }


        [Fact]
        public void ShouldNotAddEditRoadIfRoadExists()
        {
            //Arrange
            Road road = null;
            RoadViewModel viewModel = new RoadViewModel();
            viewModel.Name = "Beechurst";
            viewModel.City = "Morgantown";
            viewModel.State = "WV";
            viewModel.Zip = "26505";
            this.mockRoadRepo.Setup(m => m.AddRoad(It.IsAny<Road>())).Returns(1).Callback<Road>(m => road = m);
            this.mockRoadRepo.Setup(m => m.ListAllRoads()).Returns(CreateMockRoads());

            //Act
            this.controller.AddRoad(viewModel);
            this.controller.EditRoad(viewModel);


            //Assert
            this.mockRoadRepo.Verify(m => m.AddRoad(It.IsAny<Road>()), Times.Never);
            this.mockRoadRepo.Verify(m => m.EditRoad(It.IsAny<Road>()), Times.Never);
        }

        [Fact]
        public void ShouldNotAddEditRoad()
        {
            //Arrange
            RoadViewModel viewModel = new RoadViewModel();
            viewModel.Name = null;
            viewModel.City = "Morgantown";
            viewModel.State = "WV";
            viewModel.Zip = "26505";
            string expectedError = "The Name field is required.";
            var results = new List<ValidationResult>();

            //Act
            bool isValid = Validator.TryValidateObject(viewModel, new ValidationContext(viewModel), results);

            //Assert
            Assert.False(isValid);
            Assert.Equal(expectedError, results[0].ErrorMessage);
        }


        [Fact]
        public void ShouldEditRoad()
        {
            //Arrange
            Road road = new Road("Beechurst", "Morgantown", "WV", "26505");
            road.RoadId = 1;

            RoadViewModel viewModel = new RoadViewModel();
            viewModel.Name = "Beechurst Ave";
            viewModel.City = "Morgantown";
            viewModel.State = "WV";
            viewModel.Zip = "26505";
            viewModel.RoadId = road.RoadId;
            this.mockRoadRepo.Setup(m => m.ListAllRoads()).Returns(CreateMockRoads());

            //Road editedRoad = null;

            this.mockRoadRepo.Setup(m => m.FindRoad(road.RoadId)).Returns(road);
            //this.mockRoadRepo.Setup(m => m.EditRoad(road)).Callback<Road>(r => editedRoad = r);

            //Act
            this.controller.EditRoad(viewModel);

            //Assert
            this.mockRoadRepo.Verify(m => m.EditRoad(road), Times.Once);
            Assert.Equal(viewModel.Name, road.Name);
            Assert.Equal(viewModel.City, road.City);
            Assert.Equal(viewModel.State, road.State);
            Assert.Equal(viewModel.Zip, road.Zip);
        }


        [Fact]
        public void ShouldDeleteRoad() 
        {
            //Arrange
            RoadViewModel viewModel = new RoadViewModel();
            viewModel.Name = "Beechurst Ave";
            viewModel.City = "Morgantown";
            viewModel.State = "WV";
            viewModel.Zip = "26505";
            viewModel.RoadId = 1;
            Road road = new Road(viewModel.Name, viewModel.City, viewModel.State, viewModel.Zip);
            this.mockRoadRepo.Setup(m => m.FindRoad(viewModel.RoadId)).Returns(road);

            //Act
            this.controller.DeleteRoad(viewModel);

            //Assert
            this.mockRoadRepo.Verify(m => m.DeleteRoad(It.IsAny<Road>()), Times.Once);

        }

        [Fact]
        public void ShouldNotDeleteRoad()
        {
            //Arrange
            RoadViewModel viewModel = new RoadViewModel();
            viewModel.Name = "Beechurst Ave";
            viewModel.City = "Morgantown";
            viewModel.State = "WV";
            viewModel.Zip = "26505";
            viewModel.RoadId = 1;
            Road road = new Road(viewModel.Name, viewModel.City, viewModel.State, viewModel.Zip);
            road.RoadCrashes.Add(new RoadCrash(1, 1));
            this.mockRoadRepo.Setup(m => m.FindRoad(viewModel.RoadId)).Returns(road);

            //Act
            this.controller.DeleteRoad(viewModel);

            //Assert
            this.mockRoadRepo.Verify(m => m.DeleteRoad(It.IsAny<Road>()), Times.Never);
        }


        public List<Road> CreateMockRoads()
        {
            List<Road> roads = new List<Road>();
            Road road = new Road("Beechurst", "Morgantown", "WV", "26003");
            road.RoadId = 1;
            Crash crash = new Crash(new DateTime(2023, 09, 13), Crash.Severity.NonFatalCrash);
            crash.CrashID = 100;// Had to make a variable for crashID because ID gets generated from database side and we're not using the database
            RoadCrash roadCrash = new RoadCrash(road.RoadId, crash.CrashID);
            roadCrash.Road = road;
            roadCrash.Crash = crash;// This is object oriented navigation for all of our actions.
            road.RoadCrashes.Add(roadCrash);// RoadCrashes is a list of RoadCrash so had to create roadCrash to add to the list

            crash = new Crash(new DateTime(2023, 07, 13), Crash.Severity.Severe);
            crash.CrashID = 101;// Had to make a variable for crashID because ID gets generated from database side and we're not using the database
            roadCrash = new RoadCrash(road.RoadId, crash.CrashID);
            roadCrash.Road = road;
            roadCrash.Crash = crash;// This is object oriented navigation for all of our actions.
            road.RoadCrashes.Add(roadCrash);
            roads.Add(road);

            road = new Road("University Ave", "Morgantown", "WV", "26003");
            road.RoadId = 2;
            crash = new Crash(new DateTime(2022, 09, 13), Crash.Severity.ExtremlySevere);
            crash.CrashID = 200;// Had to make a variable for crashID because ID gets generated from database side and we're not using the database
            roadCrash = new RoadCrash(road.RoadId, crash.CrashID);
            roadCrash.Road = road;
            roadCrash.Crash = crash;// This is object oriented navigation for all of our actions.
            road.RoadCrashes.Add(roadCrash);// RoadCrashes is a list of RoadCrash so had to create roadCrash to add to the list

            crash = new Crash(new DateTime(2022, 07, 13), Crash.Severity.Severe);
            crash.CrashID = 201;// Had to make a variable for crashID because ID gets generated from database side and we're not using the database
            roadCrash = new RoadCrash(road.RoadId, crash.CrashID);
            roadCrash.Road = road;
            roadCrash.Crash = crash;// This is object oriented navigation for all of our actions.
            road.RoadCrashes.Add(roadCrash);
            roads.Add(road);

            road = new Road("Campus Drive", "Morgantown", "WV", "26003");
            road.RoadId = 3;
            crash = new Crash(new DateTime(2021, 09, 13), Crash.Severity.Severe);
            crash.CrashID = 300;// Had to make a variable for crashID because ID gets generated from database side and we're not using the database
            roadCrash = new RoadCrash(road.RoadId, crash.CrashID);
            roadCrash.Road = road;
            roadCrash.Crash = crash;// This is object oriented navigation for all of our actions.
            road.RoadCrashes.Add(roadCrash);// RoadCrashes is a list of RoadCrash so had to create roadCrash to add to the list

            crash = new Crash(new DateTime(2021, 07, 13), Crash.Severity.Severe);
            crash.CrashID = 301;// Had to make a variable for crashID because ID gets generated from database side and we're not using the database
            roadCrash = new RoadCrash(road.RoadId, crash.CrashID);
            roadCrash.Road = road;
            roadCrash.Crash = crash;// This is object oriented navigation for all of our actions.
            road.RoadCrashes.Add(roadCrash);
            roads.Add(road);

            return roads;
        }

    }
}
