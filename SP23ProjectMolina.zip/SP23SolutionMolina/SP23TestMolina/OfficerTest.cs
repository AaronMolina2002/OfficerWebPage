using SP23LibraryMolina;

namespace SP23TestMolina
{
    public class OfficerTest
    {
        [Fact]
        public void ShouldProvideOfficerName()
        {
            Officer officer = new Officer("Bob", "Huggins", "3040000001", "Test@test.com", "TestPassword");
            string expectedLastName = "Huggins";
            string actualLastName = officer.Lastname;
            Assert.Equal(expectedLastName, actualLastName);

            string expectedFullName = "Bob Huggins";
            string actualFullName = officer.Fullname;
            Assert.Equal(expectedFullName, actualFullName);
        }
    }
}