﻿using Moq;
using SP23LibraryMolina;
using SP23MvcAppMolina.Controllers;
using SP23MvcAppMolina.Models;
using SP23MvcAppMolina.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SP23TestMolina
{
    public class CrashTest
    {
        private Mock<ICrashRepo> mockCrashRepo;
        private Mock<IOfficerCrashRepo> mockOfficerCrashRepo;
        private Mock<IRoadCrashRepo> mockRoadCrashRepo;
        private Mock<IRoadRepo> mockRoadRepo;
        private Mock<IOfficerRepo> mockOfficerRepo;
        private Mock<IApplicationUserRepo> mockApplicationUserRepo;
        private CrashController controller;


        public CrashTest()
        {
            this.mockCrashRepo = new Mock<ICrashRepo>();
            this.mockOfficerCrashRepo = new Mock<IOfficerCrashRepo>();
            this.mockRoadCrashRepo = new Mock<IRoadCrashRepo>();
            this.mockRoadRepo = new Mock<IRoadRepo>();
            this.mockOfficerRepo = new Mock<IOfficerRepo>();
            this.mockApplicationUserRepo = new Mock<IApplicationUserRepo>();
            this.controller = new CrashController(this.mockCrashRepo.Object, this.mockOfficerCrashRepo.Object, this.mockRoadCrashRepo.Object, this.mockRoadRepo.Object, this.mockOfficerRepo.Object, this.mockApplicationUserRepo.Object);
        }
        //TDD - Test Driven Development

        [Fact]
        public void ShouldNotReportCrashBecauseNoRoadID()
        {
            //AAA
            //Arrange
            ReportCrashViewModel viewModel = new ReportCrashViewModel();
            viewModel.CrashEntry = new Crash(new DateTime(2023, 09, 01), Crash.Severity.NonFatalCrash);
            this.mockRoadRepo.Setup(m => m.ListAllRoads()).Returns(new List<Road>());
            this.mockOfficerRepo.Setup(m => m.ListAllOfficers()).Returns(new List<Officer>());
            this.mockOfficerRepo.Setup(m => m.FindOfficer("")).Returns(new Officer());
            this.mockApplicationUserRepo.Setup(m => m.FindCurrentUserID()).Returns("123456");

            //Act
            this.controller.ReportCrash(viewModel);

            //Assert
            this.mockCrashRepo.Verify(m => m.AddCrash(It.IsAny<Crash>()), Times.Never);
        }

        [Fact]
        public void ShouldReportCrash()
        {
            //AAA
            //Arrange
            ReportCrashViewModel viewModel = new ReportCrashViewModel();
            viewModel.CrashEntry = new Crash(new DateTime(2023, 09, 01), Crash.Severity.NonFatalCrash);
            viewModel.RoadIds = new List<int> { 1, 2, 3 };
            viewModel.AssistingOfficerIds = new List<string> { "1",  "2", "3" };
            this.mockCrashRepo.Setup(m => m.AddCrash(viewModel.CrashEntry)).Returns(1);
            this.mockOfficerCrashRepo.Setup(m => m.AddOfficerCrash(It.IsAny<OfficerCrash>())).Returns(2);
            this.mockRoadCrashRepo.Setup(m => m.AddRoadCrash(It.IsAny<RoadCrash>())).Returns(3);
            this.mockApplicationUserRepo.Setup(m => m.FindCurrentUserID()).Returns("123456");

            //Act
            this.controller.ReportCrash(viewModel);

            //Assert
            this.mockCrashRepo.Verify(m => m.AddCrash(viewModel.CrashEntry), Times.Once);
            this.mockRoadCrashRepo.Verify(m => m.AddRoadCrash(It.IsAny<RoadCrash>()), Times.Exactly(3));
            this.mockOfficerCrashRepo.Verify(m => m.AddOfficerCrash(It.IsAny<OfficerCrash>()), Times.Exactly(4));
            this.mockApplicationUserRepo.Verify(m => m.FindCurrentUserID(), Times.Once);
        }


    }
}
