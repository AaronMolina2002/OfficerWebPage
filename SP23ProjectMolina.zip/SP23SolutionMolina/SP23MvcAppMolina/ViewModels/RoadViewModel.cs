﻿//using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;

namespace SP23MvcAppMolina.ViewModels
{
    public class RoadViewModel
    {
        public int RoadId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string State { get; set; }
        [Required]
        [DataType(DataType.PostalCode)]
        public string Zip { get; set; }
    }
}
