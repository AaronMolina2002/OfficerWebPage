﻿namespace SP23MvcAppMolina.ViewModels
{
    public class AssignRoleViewModel
    {
        public string RoleName { get; set; }
        public string UserID { get; set; }
    }
}
