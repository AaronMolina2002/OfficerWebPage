﻿using SP23LibraryMolina;
using System.ComponentModel.DataAnnotations;

namespace SP23MvcAppMolina.ViewModels
{
    public class ReportCrashViewModel
    {
        [Required(ErrorMessage ="Need to enter all Crash Values")]
        public Crash CrashEntry { get; set; } 
        public List<string> AssistingOfficerIds { get; set; } 
        public List<int> RoadIds { get; set; }
    }
}
