﻿using SP23LibraryMolina;
using System.ComponentModel.DataAnnotations;

namespace SP23MvcAppMolina.ViewModels
{
    public class FindRoadsViewModel
    {
        //Search criteria: Road, SeverityLevel, StartDate, EndDate (optional)
        //Input parameters
        //drop down list
        public int? RoadId { get; set; }
        public Crash.Severity? SeverityLevel { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? EndDate { get; set; }

        //Result of search
        public List<Road> SearchRoadsResult { get; set; }
    }
}
