﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SP23LibraryMolina;
using SP23MvcAppMolina.Data;
using SP23MvcAppMolina.Models;
using SP23MvcAppMolina.ViewModels;
using System.Security.Claims;

namespace SP23MvcAppMolina.Controllers
{
    [Authorize(Roles = "Engineer, Administrator, Officer")]
    public class CrashController : Controller
    {
        //private ApplicationDbContext _database;
        private ICrashRepo iCrashRepo;
        private IOfficerCrashRepo iOfficerCrashRepo;
        private IRoadCrashRepo iRoadCrashRepo;
        private IRoadRepo iRoadRepo;
        private IOfficerRepo iOfficerRepo;
        private IApplicationUserRepo iApplicationUserRepo;

        //dependency injection
        public CrashController(ICrashRepo crashRepo, IOfficerCrashRepo officerCrashRepo, IRoadCrashRepo roadCrashRepo, IRoadRepo roadRepo, IOfficerRepo officerRepo, IApplicationUserRepo iApplicationUserRepo)
        {
            this.iCrashRepo = crashRepo;
            this.iOfficerCrashRepo = officerCrashRepo;
            this.iRoadCrashRepo = roadCrashRepo;
            this.iRoadRepo = roadRepo;
            this.iOfficerRepo = officerRepo;
            this.iApplicationUserRepo = iApplicationUserRepo;
        }

        public IActionResult ShowCrashDetails(int crashId)
        {
            // get List from database,
            //Crash crash = _database.Crash.Include(c => c.RoadCrashes).ThenInclude(rc => rc.Road).Include(c => c.RespondingOfficers).ThenInclude(ro => ro.Officer).FirstOrDefault(c => c.CrashID == crashId);
            //if (crash == null)
            //{
            //    return NotFound();
            //}
            //// List&lt;Officer&gt; officers = crash.RespondingOfficer.Select(ro =&gt; ro.Officer).ToList();
            //var viewModel = new ShowCrashDetailsViewModel
            //{
            //    Crash = crash
            //};
            return View(this.iCrashRepo.FindCrash(crashId));
        }

        //Added comment to ListAllUsers
        public IActionResult ListAllCrashes(int? roadID = null)
        {
            //List<Crash> allCrashes = _database.Crash.Include(c => c.RoadCrashes).ThenInclude(rc => rc.Road).Include(c => c.RespondingOfficers).ThenInclude(ro => ro.Officer).ToList();
            List<Crash> allCrashes = this.iCrashRepo.ListAllCrashes();
            if (roadID != null)
            {
                allCrashes = allCrashes.Where(c => c.RoadCrashes.Any(rc => rc.RoadId == roadID)).ToList();

                ViewData["RoadName"] = this.iRoadRepo.FindRoad(roadID.Value).Name;// Whenever you have optional variables, use .Value
            }
            allCrashes = allCrashes.OrderByDescending(c => c.CrashDateTime).ToList();

            return View(allCrashes);
        }

        [HttpGet]
        [Authorize(Roles ="Officer")]
        public IActionResult ReportCrash()
        {
            CreateDropDownList();
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Officer")]
        public IActionResult ReportCrash(ReportCrashViewModel viewModel)
        {
            if(viewModel.RoadIds == null)
            {
                ModelState.AddModelError("InvalidRoadId", "Need to select a Road");
            }

            if (ModelState.IsValid)
            {
                //Add a crash
                //_database.Crash.Add(viewModel.CrashEntry);
                //_database.SaveChanges();
                int crashId = this.iCrashRepo.AddCrash(viewModel.CrashEntry);
                //int crashId = viewModel.CrashEntry.CrashID;
                //string? officerId = HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);
                string officerId = this.iApplicationUserRepo.FindCurrentUserID();
                string officerRole = "Recording";

                OfficerCrash officerCrash = new OfficerCrash(crashId, officerId, officerRole);
                //_database.OfficerCrash.Add(officerCrash);
                //_database.SaveChanges();
                int officerCrashID = this.iOfficerCrashRepo.AddOfficerCrash(officerCrash);

                if (viewModel.RoadIds.Any())
                {
                    foreach (int eachRoadId in viewModel.RoadIds)
                    {
                        RoadCrash roadCrash = new RoadCrash(crashId, eachRoadId);
                        //_database.RoadCrash.Add(roadCrash);
                        //_database.SaveChanges();
                        int roadCrashID = this.iRoadCrashRepo.AddRoadCrash(roadCrash);
                    }
                }

                //Defensive programming / design
                if (viewModel.AssistingOfficerIds != null)
                {
                    if (viewModel.AssistingOfficerIds.Any())
                    {
                        if (!(viewModel.AssistingOfficerIds.Any(v => v.Contains("None"))))
                        {
                            foreach (string eachAssistingOfficerId in viewModel.AssistingOfficerIds)
                            {
                                officerCrash = new OfficerCrash(crashId, eachAssistingOfficerId, "Assisting");
                                //_database.OfficerCrash.Add(officerCrash);
                                //_database.SaveChanges();
                                officerCrashID = this.iOfficerCrashRepo.AddOfficerCrash(officerCrash);
                            }

                        }
                    }
                }

                return RedirectToAction("ListAllCrashes");

            }//end if modelstate method
            else
            {
                CreateDropDownList();
                return View(viewModel);
            }

        }//end method

        public void CreateDropDownList()
        {
            ViewData["AllRoads"] =
                new SelectList(this.iRoadRepo.ListAllRoads(), "RoadId", "Name");

            List<Officer> allOfficers = this.iOfficerRepo.ListAllOfficers();
            //string? recordingofficerId = HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);
            string recordingofficerId = this.iApplicationUserRepo.FindCurrentUserID();
            Officer reportingOfficer = this.iOfficerRepo.FindOfficer(recordingofficerId);

            allOfficers.Remove(reportingOfficer);

            ViewData["AllOfficers"] = new SelectList(allOfficers, "Id", "Fullname");
        }

    }//end class
}//end namespace
