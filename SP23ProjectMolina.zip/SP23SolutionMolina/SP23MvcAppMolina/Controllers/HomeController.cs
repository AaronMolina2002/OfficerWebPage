﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SP23LibraryMolina;
using SP23MvcAppMolina.Models;
using System.Diagnostics;
using static SP23MvcAppMolina.Models.Chart;

namespace SP23MvcAppMolina.Controllers
{
    public class HomeController : Controller
    {
        private IRoadRepo iRoadRepo;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, IRoadRepo roadRepo)
        {
            _logger = logger;
            this.iRoadRepo = roadRepo;
        }

        public IActionResult Index()
        {
            List<DataPoint> dataPoints = new List<DataPoint>();
            List<Road> allRoads = this.iRoadRepo.ListAllRoads().OrderByDescending(r => r.RoadCrashes.Count).Take(4).ToList();
            foreach (Road road in allRoads)
            {
                dataPoints.Add(new DataPoint(road.Name, road.RoadCrashes.Count, road.RoadId));
            }
            ViewData["Roads"] = JsonConvert.SerializeObject(dataPoints);
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}