﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SP23LibraryMolina;
using SP23MvcAppMolina.Data;
using SP23MvcAppMolina.Models;
using SP23MvcAppMolina.ViewModels;
using System.Collections.Generic;
using System.Data;

namespace SP23MvcAppMolina.Controllers
{
    [Authorize(Roles = "Administrator")]
    public class AppUserController : Controller
    {
        private IApplicationUserRepo iApplicationUserRepo;

        //dependency injection
        public AppUserController(IApplicationUserRepo applicationUserRepo)
        {
            this.iApplicationUserRepo = applicationUserRepo;
        }

        //Added comment to ListAllUsers
        public IActionResult ListAllUsers()
        {
            List<AppUser> allUsers = this.iApplicationUserRepo.ListAllApplicationUsers();

            return View(allUsers);
        }

        public IActionResult RevokeRole(string userId, string role)
        {
            if(!String.IsNullOrEmpty(userId) && !String.IsNullOrEmpty(role))
            {
                if (userId == this.iApplicationUserRepo.FindCurrentUserID() && role == "Administrator")
                {
                    return RedirectToAction("ListAllUsers");
                }
                //Revoke
                this.iApplicationUserRepo.RevokeRole(userId, role);
                return RedirectToAction("ListAllUsers");
            }
            else
            {
                return View("ListAllUsers");
            }
        }

        [HttpGet]
        public IActionResult AssignRole(string userID)
        {
            AssignRoleViewModel viewModel = new AssignRoleViewModel();
            viewModel.UserID = userID;
            CreateDropDownList(userID);
            ViewData["UsersName"] = this.iApplicationUserRepo.FindUser(userID);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult AssignRole(AssignRoleViewModel viewModel)
        {
            if(ModelState.IsValid) 
            {
                this.iApplicationUserRepo.AssignRole(viewModel.UserID, viewModel.RoleName);
                return RedirectToAction("ListAllUsers");
            }
            else 
            {
                CreateDropDownList(viewModel.UserID);
                return View(viewModel);
            }
        }

        public void CreateDropDownList(string userID)
        {
            ViewData["AllRoles"] = new SelectList(this.iApplicationUserRepo.ListAllAvailableRoles(userID));
        }
    }
}
