﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SP23LibraryMolina;
using SP23MvcAppMolina.Data;
using SP23MvcAppMolina.Models;
using SP23MvcAppMolina.ViewModels;


namespace SP23MvcAppMolina.Controllers
{
    [Authorize(Roles = "Engineer, Administrator, Officer")]
    public class RoadController : Controller
    {

        //private ApplicationDbContext _database;
        private IRoadRepo iRoadRepo;

        //dependency injection
        public RoadController(IRoadRepo roadRepo)
        {
            this.iRoadRepo = roadRepo;
        }

        //[HttpGet]//Client (web browser) <- web server (VS web server)
        public IActionResult FindRoadsWithMostCrashes()
        {
            ViewData["AllRoads"] = 
                new SelectList(this.iRoadRepo.ListAllRoads(), "RoadId", "Name");
            FindRoadsViewModel viewModel = new FindRoadsViewModel();
            viewModel.SearchRoadsResult = null;
            return View(viewModel);
        }

        //Search criteria:Road Name, SeverityLevel, StartDate, EndDate
        //Result: Road - Name, Zip; Crash: Severity Level, CrashDateTime
        //[HttpPost]// User entry from browser -> web server -> web browser
        public IActionResult FindRoadsWithMostCrashesResult(FindRoadsViewModel viewModel)
        {
            //List<Road> allRoads = _database.Road.Include(r => r.RoadCrashes)
                //.ThenInclude(rc => rc.Crash.RespondingOfficers).ToList();
            List<Road> allRoads = this.iRoadRepo.ListAllRoads();
            allRoads = allRoads.OrderByDescending(a => a.RoadCrashes.Count).ToList();

            if(viewModel.RoadId != null) 
            {
                allRoads = allRoads.Where(a => a.RoadId == viewModel.RoadId).ToList();
            }

            if (viewModel.SeverityLevel != null)
            {
                allRoads = allRoads
                .Where
                (a => a.RoadCrashes
                    .Any(rc => rc.Crash.SeverityLevel == viewModel.SeverityLevel)
                ).ToList();
            }

            if(viewModel.StartDate.HasValue) 
            {
                allRoads = allRoads
                    .Where(
                        a => a.RoadCrashes.Any
                            (
                                rc => rc.Crash.CrashDateTime >= viewModel.StartDate.Value
                            )
                        ).ToList();
            }

            if (viewModel.EndDate.HasValue)
            {
                allRoads = allRoads
                    .Where(
                        a => a.RoadCrashes.Any
                            (
                                rc => rc.Crash.CrashDateTime <= viewModel.EndDate.Value
                            )
                        ).ToList();
            }


            viewModel.SearchRoadsResult = allRoads;

            ViewData["AllRoads"] =
               new SelectList(this.iRoadRepo.ListAllRoads(), "RoadId", "Name");


            return View("FindRoadsWithMostCrashes", viewModel);
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public IActionResult AddRoad()
        {
            RoadViewModel viewModel = new RoadViewModel();
            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public IActionResult AddRoad(RoadViewModel viewModel)
        {
            //Any prechecks
           List<Road> roads = this.iRoadRepo.ListAllRoads().Where(r => r.Name == viewModel.Name).ToList();

            if(roads.Any())
            {
                ModelState.AddModelError("Duplicate", "This Road already exists in the system!");
            }

            if(ModelState.IsValid)
            {
                Road road = new Road(viewModel.Name, viewModel.City, viewModel.State, viewModel.Zip);
                this.iRoadRepo.AddRoad(road);
                return RedirectToAction("FindRoadsWithMostCrashes");
            }
            else
            {
                return View(viewModel);
            }
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public IActionResult EditRoad(int roadID)
        {
            Road road = this.iRoadRepo.FindRoad(roadID);
            RoadViewModel viewModel = new RoadViewModel();
            viewModel.Name = road.Name;
            viewModel.City = road.City;
            viewModel.State = road.State;
            viewModel.Zip = road.Zip;
            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public IActionResult EditRoad(RoadViewModel viewModel)
        {
            //Any prechecks
            List<Road> roads = this.iRoadRepo.ListAllRoads().Where(r => r.Name == viewModel.Name && r.RoadId != viewModel.RoadId).ToList();

            if (roads.Any())// && roads.First().Name == viewModel.Name)
            {
                ModelState.AddModelError("Duplicate", "This Road already exists in the system!");
            }

            if (ModelState.IsValid)
            {
                Road road = this.iRoadRepo.FindRoad(viewModel.RoadId);
                road.Name = viewModel.Name;
                road.City = viewModel.City;
                road.State = viewModel.State;
                road.Zip = viewModel.Zip;
                this.iRoadRepo.EditRoad(road);
                return RedirectToAction("FindRoadsWithMostCrashes");
            }
            else
            {
                return View(viewModel);
            }
        }


        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public IActionResult DeleteRoad(int roadID)
        {
            Road road = this.iRoadRepo.FindRoad(roadID);
            RoadViewModel viewModel = new RoadViewModel();
            viewModel.Name = road.Name;
            viewModel.City = road.City;
            viewModel.State = road.State;
            viewModel.Zip = road.Zip;
            return View(viewModel);
        }


        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public IActionResult DeleteRoad(RoadViewModel viewModel)
        {
            //If there are crashes on this road
            Road road = this.iRoadRepo.FindRoad(viewModel.RoadId);//Previous value
            if(road.RoadCrashes.Any())
            {
                ModelState.AddModelError("DeleteError", "This road already has crashes reported. You cannot delete!");
            }
            if(ModelState.IsValid) 
            {
                this.iRoadRepo.DeleteRoad(road);
                return RedirectToAction("FindRoadsWithMostCrashes");
            }
            else
            {
                return View(viewModel);
            }
        }
    }
}
