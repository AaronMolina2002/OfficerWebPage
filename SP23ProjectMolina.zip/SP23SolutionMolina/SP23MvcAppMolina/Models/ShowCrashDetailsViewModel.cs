﻿using SP23LibraryMolina;

namespace SP23MvcAppMolina.Models
{
    public class ShowCrashDetailsViewModel
    {
        public Crash Crash { get; set; }
    }
}
