﻿using Microsoft.EntityFrameworkCore;
using SP23LibraryMolina;
using SP23MvcAppMolina.Data;

namespace SP23MvcAppMolina.Models
{
    public class RoadRepo : IRoadRepo
    {
        private ApplicationDbContext database;
        public RoadRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public int AddRoad(Road road)
        {
            database.Road.Add(road);
            database.SaveChanges();
            return road.RoadId;
        }

        public void DeleteRoad(Road road)
        {
            this.database.Road.Remove(road);
            database.SaveChanges();
        }

        public void EditRoad(Road road)
        {
            this.database.Road.Update(road);
            this.database.SaveChanges();
        }

        public Road FindRoad(int roadID)
        {
            //return this.database.Road.Find(roadID);
            return this.database.Road.Include(r => r.RoadCrashes).Where(r => r.RoadId == roadID).FirstOrDefault();
        }

        public List<Road> ListAllRoads()
        {
            return database.Road.Include(r => r.RoadCrashes).ThenInclude(rc => rc.Crash.RespondingOfficers).ToList();
        }
    }
}
