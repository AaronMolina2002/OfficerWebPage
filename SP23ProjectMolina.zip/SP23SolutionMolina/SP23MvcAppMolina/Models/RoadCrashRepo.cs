﻿using SP23LibraryMolina;
using SP23MvcAppMolina.Data;

namespace SP23MvcAppMolina.Models
{
    public class RoadCrashRepo : IRoadCrashRepo
    {
        private ApplicationDbContext database;

        public RoadCrashRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }
        public int AddRoadCrash(RoadCrash roadCrash)
        {
            this.database.RoadCrash.Add(roadCrash);
            this.database.SaveChanges();
            return roadCrash.RoadCrashId;
        }
    }
}
