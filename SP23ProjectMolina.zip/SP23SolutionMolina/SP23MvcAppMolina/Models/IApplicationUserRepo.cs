﻿using SP23LibraryMolina;
using System.Data;

namespace SP23MvcAppMolina.Models
{
    public interface IApplicationUserRepo
    {
        public string FindCurrentUserID();
        public List<AppUser> ListAllApplicationUsers();
        public void RevokeRole(string userId, string role);
        public void AssignRole(string userId, string role);
        public List<string> ListAllAvailableRoles(string userID);
        public AppUser FindUser(string userID);
        public void EditUser(AppUser appUser);
    }
}
//Fix Pipeline
