﻿using SP23LibraryMolina;

namespace SP23MvcAppMolina.Models
{
    public interface IRoadCrashRepo
    {
        public int AddRoadCrash(RoadCrash roadCrash);
    }
}
