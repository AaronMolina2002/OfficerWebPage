﻿using SP23LibraryMolina;
using SP23MvcAppMolina.Data;

namespace SP23MvcAppMolina.Models
{
    public class OfficerCrashRepo : IOfficerCrashRepo
    {
        private ApplicationDbContext database;

        public OfficerCrashRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public int AddOfficerCrash(OfficerCrash officerCrash)
        {
            this.database.OfficerCrash.Add(officerCrash);
            this.database.SaveChanges();
            return officerCrash.OfficerCrashId;
        }
    }
}
