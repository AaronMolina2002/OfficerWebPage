﻿using SP23LibraryMolina;

namespace SP23MvcAppMolina.Models
{
    public interface ICrashRepo
    {
        public List<Crash> ListAllCrashes();
        public int AddCrash(Crash crash);//Need crash as param
        public Crash FindCrash(int crashId);
    }
}
