﻿using Microsoft.AspNetCore.Identity;
using SP23LibraryMolina;
using SP23MvcAppMolina.Data;
using System.Security.Claims;

namespace SP23MvcAppMolina.Models
{
    public class ApplicationUserRepo : IApplicationUserRepo
    {
        private IHttpContextAccessor httpContextAccessor;
        private UserManager<AppUser> userManager;
        private ApplicationDbContext database;

        public ApplicationUserRepo(IHttpContextAccessor accessor, UserManager<AppUser> userManager, ApplicationDbContext dbContext)
        {
            this.httpContextAccessor = accessor;
            this.userManager = userManager;
            this.database = dbContext;
        }

        public void AssignRole(string userId, string role)
        {
            AppUser user = this.userManager.FindByIdAsync(userId).Result;
            this.userManager.AddToRoleAsync(user, role).Wait();
        }

        public void EditUser(AppUser appUser)
        {
            this.database.AppUser.Update(appUser);
            this.database.SaveChanges();
        }

        public string FindCurrentUserID()
        {
            return this.httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);
        }

        public AppUser FindUser(string userID)
        {
            return this.database.AppUser.Find(userID);//We can use database because we are just reading data
        }

        public List<AppUser> ListAllApplicationUsers()
        {
            List<AppUser> users = this.userManager.Users.ToList();
            foreach(AppUser user in users)
            {
                user.Roles = this.userManager.GetRolesAsync(user).Result;
            }
            return users;
        }

        public List<string> ListAllAvailableRoles(string userID)
        {
            AppUser user = this.userManager.FindByIdAsync(userID).Result;
            IList<string> usersRoles = this.userManager.GetRolesAsync(user).Result;
            List<IdentityRole> roles = this.database.Roles.ToList();
            List<string> allRoles = new List<string>();
            foreach(IdentityRole role in roles) 
            {
                if(!usersRoles.Contains(role.Name))
                {
                    allRoles.Add(role.Name);
                }
            }
            return allRoles;
        }

        public void RevokeRole(string userId, string role)
        {
            AppUser user = this.userManager.FindByIdAsync(userId).Result;
            this.userManager.RemoveFromRoleAsync(user, role).Wait();
        }
    }
}
