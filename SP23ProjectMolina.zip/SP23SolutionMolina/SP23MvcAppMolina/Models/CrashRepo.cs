﻿using Microsoft.EntityFrameworkCore;
using SP23LibraryMolina;
using SP23MvcAppMolina.Data;

namespace SP23MvcAppMolina.Models
{
    public class CrashRepo : ICrashRepo
    {
        private ApplicationDbContext database;

        public CrashRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }
        public int AddCrash(Crash crash)
        {
            this.database.Crash.Add(crash);
            this.database.SaveChanges();
            return crash.CrashID;
        }

        public Crash FindCrash(int crashId)
        {
            return this.database.Crash.Include(c => c.RespondingOfficers).ThenInclude(ro => ro.Officer).Include(c => c.RoadCrashes).ThenInclude(rc => rc.Road).Where(c => c.CrashID == crashId).FirstOrDefault(); //Can't use Find when joining. 
        }

        public List<Crash> ListAllCrashes()
        {
            return this.database.Crash.Include(c => c.RoadCrashes).ThenInclude(rc => rc.Road).Include(c => c.RespondingOfficers).ThenInclude(ro => ro.Officer).ToList();
        }
    }
}
