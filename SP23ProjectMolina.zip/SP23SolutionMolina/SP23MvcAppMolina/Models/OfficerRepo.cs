﻿using SP23LibraryMolina;
using SP23MvcAppMolina.Data;

namespace SP23MvcAppMolina.Models
{
    public class OfficerRepo : IOfficerRepo
    {
        private ApplicationDbContext database;

        public OfficerRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public Officer FindOfficer(string officerID)
        {
            return this.database.Officer.Find(officerID);
        }

        public List<Officer> ListAllOfficers()
        {
            return this.database.Officer.ToList<Officer>();
        }
    }
}
