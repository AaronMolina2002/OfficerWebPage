﻿using SP23LibraryMolina;

namespace SP23MvcAppMolina.Models
{
    public interface IOfficerCrashRepo
    {
        public int AddOfficerCrash(OfficerCrash officerCrash);
    }
}
