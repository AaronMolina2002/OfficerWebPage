﻿using SP23LibraryMolina;

namespace SP23MvcAppMolina.Models
{
    public interface IRoadRepo //Interface is a library of funtionality that is explained but not implemented.
    {
        List<Road> ListAllRoads();
        int AddRoad(Road road);
        void EditRoad(Road road);
        void DeleteRoad(Road road);
        Road FindRoad(int roadID);
    }
}
