﻿using SP23LibraryMolina;

namespace SP23MvcAppMolina.Models
{
    public interface IOfficerRepo
    {
        public List<Officer> ListAllOfficers();
        public Officer FindOfficer(string officerID);
    }
}
