﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SP23LibraryMolina;

namespace SP23MvcAppMolina.Data
{
    public class ApplicationDbContext : IdentityDbContext //Datebase in .NET
    {
        public DbSet<AppUser> AppUser { get; set; } //table
        public DbSet<Officer> Officer { get; set; } //table
        public DbSet<Crash> Crash { get; set; }
        public DbSet<OfficerCrash> OfficerCrash { get; set; }
        public DbSet<Engineer> Engineer { get; set; }
        public DbSet<Road> Road { get; set; }
        public DbSet<RoadCrash> RoadCrash { get; set; }
        public DbSet<InspectionZone> InspectionZone { get; set; }
        public DbSet<Hazard> Hazard { get; set; }
        public DbSet<RoadHazard> RoadHazard { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}