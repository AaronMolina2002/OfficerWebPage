﻿using Microsoft.AspNetCore.Identity;
using SP23LibraryMolina;
using System;

namespace SP23MvcAppMolina.Data
{
    public class InitialDatabase
    {
        //object / instance methods
        //class methods
        public static void SeedDatabase(IServiceProvider services)
        {
            //1. Database service
            ApplicationDbContext database = 
                services.GetRequiredService <ApplicationDbContext>();

            //2. Roles service
            RoleManager<IdentityRole> roleManager =
                services.GetRequiredService<RoleManager<IdentityRole>>();

            //3. Users service
            UserManager<AppUser> userManager =
                services.GetRequiredService<UserManager<AppUser>>();


            string officerRole = "Officer";
            string administratorRole = "Administrator";
            string engineerRole = "Engineer";

            //Roles for app users
            if (!database.Roles.Any())
            {
                IdentityRole role = new IdentityRole(officerRole);
                roleManager.CreateAsync(role).Wait();

                role = new IdentityRole(administratorRole);
                roleManager.CreateAsync(role).Wait();

                role = new IdentityRole(engineerRole);
                roleManager.CreateAsync(role).Wait();
            }
            
            //1 User for each role
            if(!database.AppUser.Any()) 
            {
                Officer officer = new Officer("Test", "Officer1",
                    "3040000001", "Test.Officer1@test.com", "Test.Officer1");
                userManager.CreateAsync(officer).Wait();
                userManager.AddToRoleAsync(officer, officerRole).Wait();

                //Create a second officer
                Officer officer2 = new Officer("Test", "Officer2",
                    "3040000002", "Test.Officer2@test.com", "Test.Officer2");
                userManager.CreateAsync(officer2).Wait();
                userManager.AddToRoleAsync(officer2, officerRole).Wait();

                AppUser appUser = new AppUser("Test", "Administrator1",
                    "3040000002", "Test.Administrator1@test.com", 
                    "Test.Administrator1");
                userManager.CreateAsync(appUser).Wait();  
                userManager.AddToRoleAsync(appUser, administratorRole).Wait();

                //Create an AppUser - second Administrator
                AppUser appUser2 = new AppUser("Test", "Administrator2",
                    "3040000003", "Test.Administrator2@test.com",
                    "Test.Administrator2");
                userManager.CreateAsync(appUser2).Wait();
                userManager.AddToRoleAsync(appUser2, administratorRole).Wait();

                Engineer engineer = new Engineer("Test", "Engineer1",
                    "3040000011", "Test.Engineer1@test.com",
                    "Test.Engineer1");
                userManager.CreateAsync(engineer).Wait();
                userManager.AddToRoleAsync(engineer, engineerRole).Wait();

                Engineer engineer2 = new Engineer("Test", "Engineer2",
                    "3040000012", "Test.Engineer2@test.com",
                    "Test.Engineer2");
                userManager.CreateAsync(engineer2).Wait();
                userManager.AddToRoleAsync(engineer2, engineerRole).Wait();
            }

            //2. 2 rows for Crashes
            if(!database.Crash.Any())
            { 
                DateTime crashDateTime = DateTime.Now.AddDays(-1);
                Crash crash = new Crash(crashDateTime);
                database.Crash.Add(crash);
                database.SaveChanges();

                crashDateTime = new DateTime(2023, 2, 27, 23, 45, 13);
                crash = new Crash(crashDateTime);
                database.Crash.Add(crash);
                database.SaveChanges();

                crashDateTime = DateTime.Now.AddDays(-2).Date;
                crash = new Crash(crashDateTime);
                database.Crash.Add(crash);
                database.SaveChanges();

                crashDateTime = DateTime.Now.AddDays(-3).Date;
                crash = new Crash(crashDateTime);
                database.Crash.Add(crash);
                database.SaveChanges();

                crashDateTime = DateTime.Now.AddDays(-4).Date;
                crash = new Crash(crashDateTime);
                database.Crash.Add(crash);
                database.SaveChanges();
            }

            //3. OfficerCrash
            if(!database.OfficerCrash.Any()) 
            {
                int crashId = 1;
                    AppUser appUser = database.AppUser
                    .Where(a => a.UserName == "Test.Officer1@test.com").First();
                string officerId = appUser.Id;

                string officerRoleInCrash = "Recording";
                string severityOfCrash = "Non-Fatal Crash";
                OfficerCrash officerCrash = 
                    new OfficerCrash(crashId, officerId, officerRoleInCrash);
                database.OfficerCrash.Add(officerCrash);
                database.SaveChanges();

                //Associate the second officer with the second and third crashes
                crashId = 2;
                appUser = database.AppUser
                .Where(a => a.UserName == "Test.Officer2@test.com").First();
                officerId = appUser.Id;

                officerRoleInCrash = "Recording";
                severityOfCrash = "Non-Fatal Crash";
                officerCrash =
                    new OfficerCrash(crashId, officerId, officerRoleInCrash);
                database.OfficerCrash.Add(officerCrash);
                database.SaveChanges();


                crashId = 3;
                appUser = database.AppUser
                .Where(a => a.UserName == "Test.Officer2@test.com").First();
                officerId = appUser.Id;

                officerRoleInCrash = "Recording";
                severityOfCrash = "Severe Crash";
                officerCrash =
                    new OfficerCrash(crashId, officerId, officerRoleInCrash);
                database.OfficerCrash.Add(officerCrash);
                database.SaveChanges();


                crashId = 4;
                appUser = database.AppUser
                .Where(a => a.UserName == "Test.Officer1@test.com").First();
                officerId = appUser.Id;

                officerRoleInCrash = "Recording";
                severityOfCrash = "Severe Crash";
                officerCrash =
                    new OfficerCrash(crashId, officerId, officerRoleInCrash);
                database.OfficerCrash.Add(officerCrash);
                database.SaveChanges();


                crashId = 5;
                appUser = database.AppUser
                .Where(a => a.UserName == "Test.Officer1@test.com").First();
                officerId = appUser.Id;

                officerRoleInCrash = "Recording";
                severityOfCrash = "Fatal Crash";
                officerCrash =
                    new OfficerCrash(crashId, officerId, officerRoleInCrash);
                database.OfficerCrash.Add(officerCrash);
                database.SaveChanges();
            }
            

            if(!database.Road.Any())
            {
                string name = "Beechurst Ave";
                string city = "Morgantown";
                string state = "WV";
                string zip = "26505";

                Road road = new Road(name, city, state, zip);
                database.Road.Add(road);
                database.SaveChanges();

                name = "College Ave";
                city = "Morgantown";
                state = "WV";
                zip = "26505";

                road = new Road(name, city, state, zip);
                database.Road.Add(road);
                database.SaveChanges();

                name = "Canyon Road";
                city = "Morgantown";
                state = "WV";
                zip = "26508";

                road = new Road(name, city, state, zip);
                database.Road.Add(road);
                database.SaveChanges();

                name = "Cheat Road";
                city = "Morgantown";
                state = "WV";
                zip = "26508";

                road = new Road(name, city, state, zip);
                database.Road.Add(road);
                database.SaveChanges();

                name = "17th Street";
                city = "Morgantown";
                state = "WV";
                zip = "26508";

                road = new Road(name, city, state, zip);
                database.Road.Add(road);
                database.SaveChanges();
            }

            if(!database.RoadCrash.Any())
            {
                int crashId = 1;
                int roadId = 1;

                RoadCrash roadCrash = new RoadCrash(crashId, roadId);
                database.RoadCrash.Add(roadCrash);
                database.SaveChanges();


                crashId = 2;
                roadId = 2;    

                roadCrash = new RoadCrash(crashId, roadId);
                database.RoadCrash.Add(roadCrash);
                database.SaveChanges();


                crashId = 3;
                roadId = 3;

                roadCrash = new RoadCrash(crashId, roadId);
                database.RoadCrash.Add(roadCrash);
                database.SaveChanges();

                crashId = 1;
                roadId = 2;

                roadCrash = new RoadCrash(crashId, roadId);
                database.RoadCrash.Add(roadCrash);
                database.SaveChanges();

                crashId = 3;
                roadId = 4;

                roadCrash = new RoadCrash(crashId, roadId);
                database.RoadCrash.Add(roadCrash);
                database.SaveChanges();

                crashId = 3;
                roadId = 5;

                roadCrash = new RoadCrash(crashId, roadId);
                database.RoadCrash.Add(roadCrash);
                database.SaveChanges();

                crashId = 2;
                roadId = 1;

                roadCrash = new RoadCrash(crashId, roadId);
                database.RoadCrash.Add(roadCrash);
                database.SaveChanges();

                crashId = 2;
                roadId = 3;

                roadCrash = new RoadCrash(crashId, roadId);
                database.RoadCrash.Add(roadCrash);
                database.SaveChanges();
            }


            if(!database.InspectionZone.Any()) 
            {
                string county = "Monongalia County";
                string state = "West Virginia";
                string startZip = "26501";
                string endZip = "26505";
                AppUser appUser = database.AppUser
                    .Where(a => a.UserName == "Test.Engineer1@test.com").First();
                string engineerId = appUser.Id;

                InspectionZone inspectionZone =
                    new InspectionZone(county, state, startZip, endZip, engineerId);
                database.InspectionZone.Add(inspectionZone);
                database.SaveChanges();


                county = "Monongalia County";
                state = "West Virginia";
                startZip = "26506";
                endZip = "26510";
                appUser = database.AppUser
                    .Where(a => a.UserName == "Test.Engineer2@test.com").First();
                engineerId = appUser.Id;

                inspectionZone =
                    new InspectionZone(county, state, startZip, endZip, engineerId);
                database.InspectionZone.Add(inspectionZone);
                database.SaveChanges();
            }

            if(!database.Hazard.Any())
            {
                string hazardType = "Potholes";

                Hazard hazard = new Hazard(hazardType);
                database.Hazard.Add(hazard);
                database.SaveChanges();


                hazardType = "Blind Spots";

                hazard = new Hazard(hazardType);
                database.Hazard.Add(hazard);
                database.SaveChanges();


                hazardType = "Excessive Speed Limit";

                hazard = new Hazard(hazardType);
                database.Hazard.Add(hazard);
                database.SaveChanges();
            }


            if(!database.RoadHazard.Any())
            {
                int roadId = 1;
                int hazardId = 1;

                RoadHazard roadHazard = new RoadHazard(roadId, hazardId);
                database.RoadHazard.Add(roadHazard);
                database.SaveChanges();


                roadId = 2;
                hazardId = 3;

                roadHazard = new RoadHazard(roadId, hazardId);
                database.RoadHazard.Add(roadHazard);
                database.SaveChanges();


                roadId = 3;
                hazardId = 2;

                roadHazard = new RoadHazard(roadId, hazardId);
                database.RoadHazard.Add(roadHazard);
                database.SaveChanges();


                roadId = 4;
                hazardId = 3;

                roadHazard = new RoadHazard(roadId, hazardId);
                database.RoadHazard.Add(roadHazard);
                database.SaveChanges();


                roadId = 5;
                hazardId = 1;

                roadHazard = new RoadHazard(roadId, hazardId);
                database.RoadHazard.Add(roadHazard);
                database.SaveChanges();
            }

        }//end Seed Database method
    }// end class
}//end namespace
