﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SP23MvcAppMolina.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddedHazardInspectionZoneAndRoadHazard : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CrashLocation",
                table: "Crash");

            migrationBuilder.AddColumn<int>(
                name: "SeverityLevel",
                table: "Crash",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Hazard",
                columns: table => new
                {
                    HazardId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HazardType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Hazard", x => x.HazardId);
                });

            migrationBuilder.CreateTable(
                name: "InspectionZone",
                columns: table => new
                {
                    InspectionZoneId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    County = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StartZip = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EndZip = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EngineerId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InspectionZone", x => x.InspectionZoneId);
                    table.ForeignKey(
                        name: "FK_InspectionZone_AspNetUsers_EngineerId",
                        column: x => x.EngineerId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Road",
                columns: table => new
                {
                    RoadId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Zip = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Road", x => x.RoadId);
                });

            migrationBuilder.CreateTable(
                name: "RoadCrash",
                columns: table => new
                {
                    RoadCrashId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CrashId = table.Column<int>(type: "int", nullable: false),
                    RoadId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoadCrash", x => x.RoadCrashId);
                    table.ForeignKey(
                        name: "FK_RoadCrash_Crash_CrashId",
                        column: x => x.CrashId,
                        principalTable: "Crash",
                        principalColumn: "CrashID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_RoadCrash_Road_RoadId",
                        column: x => x.RoadId,
                        principalTable: "Road",
                        principalColumn: "RoadId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RoadHazard",
                columns: table => new
                {
                    RoadHazardId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoadId = table.Column<int>(type: "int", nullable: false),
                    HazardId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoadHazard", x => x.RoadHazardId);
                    table.ForeignKey(
                        name: "FK_RoadHazard_Hazard_HazardId",
                        column: x => x.HazardId,
                        principalTable: "Hazard",
                        principalColumn: "HazardId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_RoadHazard_Road_RoadId",
                        column: x => x.RoadId,
                        principalTable: "Road",
                        principalColumn: "RoadId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_InspectionZone_EngineerId",
                table: "InspectionZone",
                column: "EngineerId");

            migrationBuilder.CreateIndex(
                name: "IX_RoadCrash_CrashId",
                table: "RoadCrash",
                column: "CrashId");

            migrationBuilder.CreateIndex(
                name: "IX_RoadCrash_RoadId",
                table: "RoadCrash",
                column: "RoadId");

            migrationBuilder.CreateIndex(
                name: "IX_RoadHazard_HazardId",
                table: "RoadHazard",
                column: "HazardId");

            migrationBuilder.CreateIndex(
                name: "IX_RoadHazard_RoadId",
                table: "RoadHazard",
                column: "RoadId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "InspectionZone");

            migrationBuilder.DropTable(
                name: "RoadCrash");

            migrationBuilder.DropTable(
                name: "RoadHazard");

            migrationBuilder.DropTable(
                name: "Hazard");

            migrationBuilder.DropTable(
                name: "Road");

            migrationBuilder.DropColumn(
                name: "SeverityLevel",
                table: "Crash");

            migrationBuilder.AddColumn<string>(
                name: "CrashLocation",
                table: "Crash",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
