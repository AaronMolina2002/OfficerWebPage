﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SP23MvcAppMolina.Data.Migrations
{
    /// <inheritdoc />
    public partial class EditedOfficerCrash : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SeverityOfCrash",
                table: "OfficerCrash");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "SeverityOfCrash",
                table: "OfficerCrash",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
