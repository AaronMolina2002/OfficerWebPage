﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SP23MvcAppMolina.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddedCrashAndOfficerCrash : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Crash",
                columns: table => new
                {
                    CrashID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CrashDateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ReportingDateTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Crash", x => x.CrashID);
                });

            migrationBuilder.CreateTable(
                name: "OfficerCrash",
                columns: table => new
                {
                    OfficerCrashId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CrashId = table.Column<int>(type: "int", nullable: false),
                    OfficerId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    OfficerRole = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OfficerCrash", x => x.OfficerCrashId);
                    table.ForeignKey(
                        name: "FK_OfficerCrash_AspNetUsers_OfficerId",
                        column: x => x.OfficerId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OfficerCrash_Crash_CrashId",
                        column: x => x.CrashId,
                        principalTable: "Crash",
                        principalColumn: "CrashID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OfficerCrash_CrashId",
                table: "OfficerCrash",
                column: "CrashId");

            migrationBuilder.CreateIndex(
                name: "IX_OfficerCrash_OfficerId",
                table: "OfficerCrash",
                column: "OfficerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OfficerCrash");

            migrationBuilder.DropTable(
                name: "Crash");
        }
    }
}
