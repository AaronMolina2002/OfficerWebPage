﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinalMvcAppMolina.Data.Migrations
{
    /// <inheritdoc />
    public partial class StudentAdvisor : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "StudentAdvisor",
                columns: table => new
                {
                    StudentAdvisorID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AdvisorAppointmentID = table.Column<int>(type: "int", nullable: false),
                    StudentAppointmentID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentAdvisor", x => x.StudentAdvisorID);
                    table.ForeignKey(
                        name: "FK_StudentAdvisor_AdvisorAppointment_AdvisorAppointmentID",
                        column: x => x.AdvisorAppointmentID,
                        principalTable: "AdvisorAppointment",
                        principalColumn: "AdvisorAppointmentID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StudentAdvisor_StudentAppointment_StudentAppointmentID",
                        column: x => x.StudentAppointmentID,
                        principalTable: "StudentAppointment",
                        principalColumn: "AppointmentID",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_StudentAdvisor_AdvisorAppointmentID",
                table: "StudentAdvisor",
                column: "AdvisorAppointmentID");

            migrationBuilder.CreateIndex(
                name: "IX_StudentAdvisor_StudentAppointmentID",
                table: "StudentAdvisor",
                column: "StudentAppointmentID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StudentAdvisor");
        }
    }
}
