﻿using FinalLibraryMolina;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace FinalMvcAppMolina.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<AppUser> AppUser { get; set; }
        public DbSet<Advisor> Advisor { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<StudentAppointment> StudentAppointment { get; set; }
        public DbSet<AdvisorAppointment> AdvisorAppointment { get; set; }

        public DbSet<StudentAdvisor> StudentAdvisor { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}