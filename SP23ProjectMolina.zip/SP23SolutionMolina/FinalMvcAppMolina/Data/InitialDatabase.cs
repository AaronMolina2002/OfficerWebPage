﻿using FinalLibraryMolina;
using Microsoft.AspNetCore.Identity;

namespace FinalMvcAppMolina.Data
{
    public class InitialDatabase
    {
        public static void SeedDatabase(IServiceProvider services)
        {
            //1. Database service
            ApplicationDbContext database =
                services.GetRequiredService<ApplicationDbContext>();

            //2. Roles service
            RoleManager<IdentityRole> roleManager =
                services.GetRequiredService<RoleManager<IdentityRole>>();

            //3. Users service
            UserManager<AppUser> userManager =
                services.GetRequiredService<UserManager<AppUser>>();

            string studentRole = "Student";
            string advisorRole = "Advisor";

            if (!database.Roles.Any())
            {
                IdentityRole role = new IdentityRole(studentRole);
                roleManager.CreateAsync(role).Wait();

                role = new IdentityRole(advisorRole);
                roleManager.CreateAsync(role).Wait();
            }

            if(!database.Roles.Any()) 
            {
                Advisor advisor = new Advisor("Test", "Advisor1", "304-000-0001", "TestAdvisor1@test.com", "TestAdvisor1");
                userManager.CreateAsync(advisor).Wait();
                userManager.AddToRoleAsync(advisor, advisorRole).Wait();

                Student student = new Student("Test", "Student1", "304-000-0002", "TestStudent1@test.com", "TestStudent1");
                userManager.CreateAsync(student).Wait();
                userManager.AddToRoleAsync(student, studentRole).Wait();

                student = new Student("Test", "Student2", "304-000-0003", "TestStudent2@test.com", "TestStudent2");
                userManager.CreateAsync(student).Wait();
                userManager.AddToRoleAsync(student, studentRole).Wait();
            }

            if(!database.StudentAppointment.Any())
            {
                AppUser appUser = database.AppUser.Where(a => a.UserName == "TestStudent1@test.com").First();
                string studentID = appUser.Id;

                appUser = database.AppUser.Where(a => a.UserName == "TestStudent2@test.com").First();
                string studentID2 = appUser.Id;

                DateTime appointmentDate = DateTime.Now;

                appointmentDate = DateTime.Now.AddDays(-2);

                appointmentDate = DateTime.Now.AddDays(-3);

                appointmentDate = DateTime.Now.AddDays(-4);

                StudentAppointment appointment = new StudentAppointment(studentID, appointmentDate);
                database.StudentAppointment.Add(appointment);
                database.SaveChanges();

                appointment = new StudentAppointment(studentID2, appointmentDate);
                database.StudentAppointment.Add(appointment);
                database.SaveChanges();

                appointment = new StudentAppointment(studentID2, appointmentDate);
                database.StudentAppointment.Add(appointment);
                database.SaveChanges();

                appointment = new StudentAppointment(studentID2, appointmentDate);
                database.StudentAppointment.Add(appointment);
                database.SaveChanges();

            }

            if(!database.AdvisorAppointment.Any())
            {
                AppUser appUser = database.AppUser.Where(a => a.UserName == "TestAdvisor1@test.com").First();
                string advisorID = appUser.Id;

                DateTime appointmentDate = DateTime.Now;

                AdvisorAppointment appointment = new AdvisorAppointment(advisorID, appointmentDate);
                database.AdvisorAppointment.Add(appointment);
                database.SaveChanges();
            }

            if(!database.StudentAdvisor.Any()) 
            {
                int studentAppointmentID = 1;
                int advisorAppointmentID = 1;

                StudentAdvisor studentAdvisor = new StudentAdvisor(advisorAppointmentID, studentAppointmentID);
                database.StudentAdvisor.Add(studentAdvisor); 
                database.SaveChanges();

                int studentAppointmentID2 = 2;
                studentAdvisor = new StudentAdvisor(advisorAppointmentID, studentAppointmentID2);
                database.StudentAdvisor.Add(studentAdvisor);
                database.SaveChanges();

                int studentAppointmentID3 = 3;
                studentAdvisor = new StudentAdvisor(advisorAppointmentID, studentAppointmentID3);
                database.StudentAdvisor.Add(studentAdvisor);
                database.SaveChanges();

                int studentAppointmentID4 = 4;
                studentAdvisor = new StudentAdvisor(advisorAppointmentID, studentAppointmentID4);
                database.StudentAdvisor.Add(studentAdvisor);
                database.SaveChanges();
            }
        }
    }
}
