﻿using FinalLibraryMolina;
using FinalMvcAppMolina.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinalMvcAppMolina.Controllers
{
    public class AppointmentsController : Controller
    {
        private ApplicationDbContext _database;

        public AppointmentsController(ApplicationDbContext database)
        {
            this._database = database;
        }

        public IActionResult ListAllAppointments()
        {
            List<StudentAppointment> appointments = _database.StudentAppointment.Include(sa => sa.Student).ToList();

            return View(appointments);
        }
    }
}
