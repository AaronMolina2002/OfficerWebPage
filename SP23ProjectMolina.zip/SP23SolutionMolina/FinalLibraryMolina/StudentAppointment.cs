﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace FinalLibraryMolina
{
    public class StudentAppointment
    {
        [Key]
        public int AppointmentID { get; set; }

        public string StudentID { get; set; }

        public DateTime AppointmentDate { get; set; }

        List<StudentAdvisor> StudentAdvisorList { get; set; } = new List<StudentAdvisor>();


        [ForeignKey(nameof(StudentID))]
        public Student Student { get; set; }

        public StudentAppointment(string studentID, DateTime appointmentDate)
        {
            StudentID = studentID;
            AppointmentDate = appointmentDate;
        }

        public StudentAppointment() { }

    }
}