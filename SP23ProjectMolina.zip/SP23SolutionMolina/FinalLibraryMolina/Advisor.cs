﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FinalLibraryMolina
{
    public class Advisor : AppUser
    {
        List<AdvisorAppointment> Appointments { get; set; } = new List<AdvisorAppointment>();

        public Advisor(string firstname, string lastname, string phoneNumber, string email, string password) : base(firstname, lastname, phoneNumber, email, password)
        {

        }

        public Advisor() { }
    }
}