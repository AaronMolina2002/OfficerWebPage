﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace FinalLibraryMolina
{
    public class StudentAdvisor
    {
        [Key]
        public int StudentAdvisorID { get; set; }

        public int AdvisorAppointmentID { get; set; }
        public int StudentAppointmentID { get; set; }

        [ForeignKey(nameof(AdvisorAppointmentID))]
        public AdvisorAppointment AdvisorAppointment { get; set; }

        [ForeignKey(nameof(StudentAppointmentID))]
        public StudentAppointment StudentAppointment { get; set; }

        public StudentAdvisor(int advisorAppointmentID, int studentAppointmentID)
        {
            AdvisorAppointmentID = advisorAppointmentID;
            StudentAppointmentID = studentAppointmentID;
        }

        public StudentAdvisor() { }
    }
}