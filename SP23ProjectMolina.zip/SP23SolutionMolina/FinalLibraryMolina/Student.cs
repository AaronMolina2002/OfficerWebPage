﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;

namespace FinalLibraryMolina
{
    public class Student : AppUser
    {
        List<StudentAppointment> Appointments { get; set; } = new List<StudentAppointment>();

        public Student(string firstname, string lastname, string phoneNumber, string email, string password) : base(firstname, lastname, phoneNumber, email, password)
        {

        }

        public Student() { }
    }
}