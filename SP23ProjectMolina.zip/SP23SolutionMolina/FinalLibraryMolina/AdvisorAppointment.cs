﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace FinalLibraryMolina
{
    public class AdvisorAppointment
    {
        [Key]
        public int AdvisorAppointmentID { get; set; }

        public string AdvisorID { get; set; }

        public AdvisorAvailability AdvisorAvb { get; set; }

        public DateTime AppointmentDate { get; set; }

        List<StudentAdvisor> StudentAdvisorsList { get; set; } = new List<StudentAdvisor>();

        [ForeignKey(nameof(AdvisorID))]
        public Advisor Advisor { get; set; }

        public AdvisorAppointment(string advisorID, DateTime appointmentDate, AdvisorAvailability advisorAvailability = AdvisorAvailability.Available)
        {
            AdvisorID = advisorID;
            AppointmentDate = appointmentDate;
            AdvisorAvb = advisorAvailability;
        }

        public AdvisorAppointment() { }

        public enum AdvisorAvailability
        {
            Available, NotAvailable
        }
    }
}