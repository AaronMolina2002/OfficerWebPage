﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FinalLibraryMolina
{
    public class AppUser : IdentityUser
    {
        //Id comes from IdentityUser
        //public string Id { get; set; } Don't create in this class. We are getting it from the parent class
        //Do we need a primary key? Is it AppUserID?
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Fullname { get { return Firstname + " " + Lastname; } }

        public AppUser(string firstname, string lastname, string phoneNumber, string email, string password)
        {
            Firstname = firstname;
            Lastname = lastname;
            this.PhoneNumber = phoneNumber;
            this.Email = email;
            this.UserName = email;
            PasswordHasher<AppUser> passwordHasher = new PasswordHasher<AppUser>();
            this.PasswordHash = passwordHasher.HashPassword(this, password);
        }

        //Object-Oriented Relational Mapping (ORM)
        //Entity Framework - ORM
        public AppUser() { } //Create a second empty constructor for Entity Framework
    }
}